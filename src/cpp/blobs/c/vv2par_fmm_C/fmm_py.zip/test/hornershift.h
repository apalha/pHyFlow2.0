void downwardshift(double* wksp1,int endk,int pshift);
void upwardshift(double* wksp1, int startk,int pshift);
void downwardshift2(double *restrict wksp1,double *restrict wksp2,int pshift);
void upwardshift2(double *restrict wksp1, double *restrict wksp2,int pshift);