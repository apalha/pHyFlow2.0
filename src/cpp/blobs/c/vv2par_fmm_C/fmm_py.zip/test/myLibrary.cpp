
double myMultiply(double x, double y){
    return x + y;
}
